
import Peer from '../lib/peerjs.min.js';

let peer;
const peerId = 'peer_' + Math.floor(Math.random() * 10000);

export function setupPeer() {
  peer = new Peer(peerId);

  peer.on('open', id => {
    console.log('Peer connected with ID:', id);
  });

  peer.on('connection', conn => {
    conn.on('data', data => {
      console.log('Received data:', data);
      // handle video requests here
    });
  });

  peer.on('error', err => {
    console.error('Peer error:', err);
  });
}
