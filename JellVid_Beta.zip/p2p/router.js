
export function routeVideoRequest(videoId) {
  console.log('Routing video request for', videoId);
}
