
export function loadUploadPage() {
  console.log('Loading upload page');
}
