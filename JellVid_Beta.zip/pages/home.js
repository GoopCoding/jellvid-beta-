
import { getAllVideos } from '../db/wrapper.js';
import { renderVideoGrid } from '../ui/grid.js';

export async function loadHome() {
  const videos = await getAllVideos();
  renderVideoGrid(videos);
}
