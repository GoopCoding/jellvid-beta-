
export function loadProfilePage() {
  console.log('Loading profile page');
}
