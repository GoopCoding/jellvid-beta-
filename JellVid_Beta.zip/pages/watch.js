
export function loadWatchPage(videoId) {
  console.log('Loading watch page for', videoId);
}
