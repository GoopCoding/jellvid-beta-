
export function uploadVideo(file, metadata) {
  console.log('Uploading video:', file.name, metadata);
  // Add video to DB and start seeding
}
