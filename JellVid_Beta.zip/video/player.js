
export function playVideo(videoId) {
  console.log('Playing video with ID:', videoId);
}
