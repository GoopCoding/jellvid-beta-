
export function streamVideoFromPeer(peerId, videoId) {
  console.log('Streaming video', videoId, 'from peer', peerId);
}
