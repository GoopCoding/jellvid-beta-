
export function renderNavbar() {
  const nav = document.getElementById('navbar');
  nav.innerHTML = 'JellVid Beta';
}
