
export function openModal(content) {
  alert(content); // Placeholder modal
}
