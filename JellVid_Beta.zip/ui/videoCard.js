
export function createVideoCard(video) {
  const card = document.createElement('div');
  card.className = 'video-card';
  card.innerHTML = '<div class="video-title">' + video.title + '</div>';
  return card;
}
