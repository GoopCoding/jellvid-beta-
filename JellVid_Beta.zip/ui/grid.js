
export function renderVideoGrid(videos) {
  const app = document.getElementById('app');
  app.innerHTML = '';
  videos.forEach(video => {
    const card = createVideoCard(video);
    app.appendChild(card);
  });
}
