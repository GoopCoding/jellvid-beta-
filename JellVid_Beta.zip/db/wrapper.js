
import { db } from './init.js';

export async function addVideo(video) {
  return db.put('videos', video);
}

export async function getVideo(id) {
  return db.get('videos', id);
}

export async function getAllVideos() {
  return db.getAll('videos');
}

export async function saveSetting(key, value) {
  return db.put('settings', { key, value });
}

export async function getSetting(key) {
  return db.get('settings', key);
}
