
export const VideoSchema = {
  id: 'string',       // unique video id
  title: 'string',
  description: 'string',
  uploadedAt: 'number', // timestamp
  fileHash: 'string',  // hash of video file
  tags: 'array',
  peerIds: 'array'    // peers seeding this video
};
