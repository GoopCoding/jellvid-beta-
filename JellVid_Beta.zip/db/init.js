
import { openDB } from '../lib/idb-keyval.min.js';

export let db;

export async function initDB() {
  db = await openDB('JellVidBetaDB', 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('videos')) {
        db.createObjectStore('videos', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    }
  });
}
