
export function formatTimestamp(ts) {
  return new Date(ts).toLocaleString();
}
