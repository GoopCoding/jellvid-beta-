import { initDB } from './db/wrapper.js';
import { setupPeer } from './p2p/peer.js';
import { renderNavbar } from './ui/navbar.js';
import { loadHome } from './pages/home.js';

async function main() {
  await initDB();
  renderNavbar();
  setupPeer();
  loadHome();
}

main();
